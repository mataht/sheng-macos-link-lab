#include <TargetConditionals.h>
static_assert(TARGET_OS_OSX == 1, "requires macOS storage ABI");
#include <libkern/libkern.h>
#define NATIVE_UFS_RECOVERY_BYTES 1577092608ULL
#define NATIVE_UFS_RECOVERY_DIGEST {97,153,229,61,60,246,12,89,121,14,80,120,81,239,72,20,29,191,162,56,117,253,222,94,131,132,70,152,78,213,104,129}
#define NATIVE_UFS_RECOVERY_UUID "808EAC5E-8275-478D-814C-2229D8EB8D07"
#define NATIVE_UFS_ISC_BYTES 2149580800ULL
#define NATIVE_UFS_ISC_DIGEST {239,54,117,219,17,16,62,179,219,68,55,133,124,208,216,117,190,98,165,225,77,127,243,177,143,119,0,223,57,115,127,113}
#define NATIVE_UFS_ISC_UUID "EB96F3FE-29C9-438B-BB52-39DE154920EB"
#include "/Users/runner/work/macOS-ForSheng/macOS-ForSheng/platform/sheng/macos26/storage/recovery_root.h"
#define NATIVE_MACOSLOG 1
#define NATIVE_MACOSLOG_FILE_ID {248,69,86,164,66,73,87,140,144,210,20,132,18,47,122,86}
#define NATIVE_MACOSLOG_PARTITION_ID {52,237,210,76,66,33,164,78,171,242,236,108,81,209,23,215}
#define NATIVE_MACOSLOG_TYPE_ID {162,160,208,235,229,185,51,68,135,192,104,182,183,38,153,199}
#define NATIVE_MACOSLOG_WORKER "/Users/runner/work/macOS-ForSheng/macOS-ForSheng/platform/sheng/macos26/storage/macoslog_worker.h"
#include "/Users/runner/work/macOS-ForSheng/macOS-ForSheng/UniXNU/drivers/NativeUfs/NativeUfs.cpp"
#include "/Users/runner/work/macOS-ForSheng/macOS-ForSheng/out/macos26-xnu-arm64e/ufs-driver/gop-display/NativeGOPDisplay.cpp"
#include <mach/kmod.h>
extern "C" kern_return_t sheng_ufs_start(kmod_info_t *, void *) { return KERN_SUCCESS; }
extern "C" kern_return_t sheng_ufs_stop(kmod_info_t *, void *) { return KERN_FAILURE; }
KMOD_EXPLICIT_DECL(org.blu-sharky.NativeUfs, "1.0.0", sheng_ufs_start, sheng_ufs_stop)
