# Driver object provenance

These two third-party upstream ARM64E objects and generated wrapper sources were extracted unchanged
from the public CrossDarwin/macOS-ForSheng CI artifact 12956372647, run
41008552166, source commit a200d204230846bb640b715086d8c627405ba2df.
NativeUfs.o includes the GOP companion. It also retains UFS code.

Original project source, build scripts, license, and patches:
https://github.com/CrossDarwin/macOS-ForSheng/tree/a200d204230846bb640b715086d8c627405ba2df
Dependency pins:
https://github.com/CrossDarwin/macOS-ForSheng/blob/a200d204230846bb640b715086d8c627405ba2df/sources.lock.json
UniXNU patches applied by that project:
https://github.com/CrossDarwin/macOS-ForSheng/tree/a200d204230846bb640b715086d8c627405ba2df/patches/UniXNU
Pinned UniXNU base source:
https://github.com/UniXNU/UniXNU/tree/fb6aad6ab1f50199a4d99d2da1d0ca403b067633

The generated wrappers retain their original public CI runner include paths.
They are provenance aids, not self-contained driver source or a rebuild SDK.
Follow the pinned source lock and patch series to obtain the matching source.
The GPL license is copied unchanged from the pinned project's LICENSE.
Original authors retain their copyrights; this lab does not claim authorship
of the drivers. No Apple firmware, BootKC, BaseSystem, KDK, device dump,
credential, or full upstream artifact ZIP is included.

This bundle only preserves inputs for a linker experiment. It is not a driver
installation package and does not establish runtime or hardware compatibility.
