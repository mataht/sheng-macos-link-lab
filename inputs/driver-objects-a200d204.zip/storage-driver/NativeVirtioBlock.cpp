#include <TargetConditionals.h>
static_assert(TARGET_OS_OSX == 1, "requires macOS storage ABI");
#include "/Users/runner/work/macOS-ForSheng/macOS-ForSheng/UniXNU/drivers/NativeVirtioBlock/NativeVirtioBlock.cpp"
#include <mach/kmod.h>
extern "C" kern_return_t sheng_virtio_start(kmod_info_t *, void *) { return KERN_SUCCESS; }
extern "C" kern_return_t sheng_virtio_stop(kmod_info_t *, void *) { return KERN_FAILURE; }
KMOD_EXPLICIT_DECL(org.unixnu.driver.NativeVirtioBlock, "1.0.0", sheng_virtio_start, sheng_virtio_stop)
